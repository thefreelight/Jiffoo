import archiver from 'archiver';
import { spawn } from 'child_process';
import { createHash, sign } from 'crypto';
import { createWriteStream } from 'fs';
import { promises as fs } from 'fs';
import os from 'os';
import path from 'path';
import {
  OFFICIAL_LAUNCH_EXTENSIONS,
  type OfficialCatalogEntry,
} from '../../../packages/shared/src/extensions/official-catalog';

type OfficialArtifactKind = 'plugin' | 'theme' | 'theme-app';

interface PluginSourceConfig {
  includeNodeModules?: boolean;
  prepareCommands?: string[];
}

interface PreparedPluginSource {
  cleanup(): Promise<void>;
}

interface BuildOfficialArtifactsOptions {
  outputDir?: string;
  artifactBaseUrl?: string;
  slugs?: string[];
  kinds?: OfficialArtifactKind[];
}

interface BuiltArtifactSummary {
  slug: string;
  kind: 'plugin' | 'theme';
  artifactKind: string;
  version: string;
  packageUrl: string;
  filePath: string;
  relativePath: string;
  sha256: string;
  sizeBytes: number;
  sourceDir: string;
  includedFiles: string[];
  signaturePath?: string;
}

interface ThemePackSourceManifest {
  schemaVersion: number;
  slug: string;
  name: string;
  version: string;
  target: 'shop' | 'admin';
  entry?: {
    tokensCSS?: string;
    templatesDir?: string;
    assetsDir?: string;
    settingsSchema?: string;
    presetsDir?: string;
  };
  compatibility?: {
    minCoreVersion?: string;
  };
  'x-jiffoo-renderer-mode'?: 'platform' | 'embedded';
  'x-jiffoo-renderer-slug'?: string;
}

interface ThemeAppSourceManifest {
  schemaVersion: number;
  type: 'theme-app';
  slug: string;
  name: string;
  version: string;
  target: 'shop' | 'admin';
  compatibility?: { minCoreVersion?: string };
}

interface BuildOfficialArtifactsResult {
  generatedAt: string;
  outputDir: string;
  items: BuiltArtifactSummary[];
}

const REPO_ROOT = path.resolve(__dirname, '../../..');
const DEFAULT_OUTPUT_DIR = path.join(REPO_ROOT, 'dist', 'official-artifacts');
const ROOT_LICENSE_PATH = path.join(REPO_ROOT, 'LICENSE');

const OFFICIAL_PLUGIN_SOURCE_CONFIG: Record<string, PluginSourceConfig> = {
  'hermes-bridge': {
    includeNodeModules: true,
    prepareCommands: [
      'npm install --no-package-lock --ignore-scripts --workspaces=false',
      'npx prisma generate --schema prisma/schema.prisma',
      'npm prune --omit=dev --no-package-lock --ignore-scripts --workspaces=false',
    ],
  },
  wallet: {
    includeNodeModules: true,
    prepareCommands: [
      'npm install --no-package-lock --ignore-scripts --workspaces=false',
      'npx prisma generate --schema prisma/schema.prisma',
      'npm prune --omit=dev --no-package-lock --ignore-scripts --workspaces=false',
    ],
  },
  stripe: {
    includeNodeModules: false,
  },
  i18n: {
    includeNodeModules: false,
  },
  odoo: {
    includeNodeModules: true,
    prepareCommands: [
      'npm ci --include=dev',
      'npm run build',
      'rm -rf node_modules',
      'npm ci --omit=dev',
    ],
  },
};

function parseArgs(argv: string[]): BuildOfficialArtifactsOptions {
  const options: BuildOfficialArtifactsOptions = {};

  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];

    if (arg === '--output' || arg === '-o') {
      options.outputDir = argv[index + 1];
      index += 1;
      continue;
    }

    if (arg === '--slug') {
      const value = argv[index + 1];
      if (value) {
        options.slugs = [...(options.slugs || []), value];
      }
      index += 1;
      continue;
    }

    if (arg === '--kind') {
      const value = argv[index + 1];
      if (value === 'plugin' || value === 'theme') {
        options.kinds = [...(options.kinds || []), value];
      }
      index += 1;
      continue;
    }

    if (arg === '--artifact-base-url') {
      options.artifactBaseUrl = argv[index + 1];
      index += 1;
      continue;
    }
  }

  return options;
}

function toOfficialArtifactKind(entry: OfficialCatalogEntry): OfficialArtifactKind {
  if (entry.artifactKind === 'theme-app-package') {
    return 'theme-app';
  }
  return entry.kind === 'plugin' ? 'plugin' : 'theme';
}

function getDefaultPackageUrl(entry: OfficialCatalogEntry, artifactBaseUrl?: string): string {
  if (!artifactBaseUrl) {
    return entry.packageUrl;
  }

  const extension = entry.artifactKind === 'theme-app-package'
    ? 'theme-app.zip'
    : entry.kind === 'theme' ? 'jtheme' : 'jplugin';
  const kindPath = entry.artifactKind === 'theme-app-package'
    ? 'theme-apps'
    : entry.kind === 'theme' ? 'themes' : 'plugins';
  return `${artifactBaseUrl.replace(/\/$/, '')}/${kindPath}/${entry.slug}/${entry.version}.${extension}`;
}

function sanitizeManifestEntryRoot(entryModule?: string): string | null {
  if (!entryModule) {
    return null;
  }

  const normalized = entryModule.replace(/\\/g, '/').replace(/^\.?\//, '');
  const [segment] = normalized.split('/');
  return segment || null;
}

async function pathExists(targetPath: string): Promise<boolean> {
  try {
    await fs.access(targetPath);
    return true;
  } catch {
    return false;
  }
}

async function ensureDir(targetPath: string): Promise<void> {
  await fs.mkdir(targetPath, { recursive: true });
}

async function runShellCommand(command: string, cwd: string): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const child = spawn(command, {
      cwd,
      shell: true,
      env: process.env,
      stdio: 'inherit',
    });

    child.on('error', reject);
    child.on('exit', (code) => {
      if (code === 0) {
        resolve();
        return;
      }

      reject(new Error(`Command failed with exit code ${code}: ${command}`));
    });
  });
}

async function copyIfExists(sourcePath: string, destPath: string): Promise<boolean> {
  if (!(await pathExists(sourcePath))) {
    return false;
  }

  await ensureDir(path.dirname(destPath));
  await fs.cp(sourcePath, destPath, { recursive: true, force: true });
  return true;
}

async function gatherFiles(dir: string, prefix = ''): Promise<string[]> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files: string[] = [];

  for (const entry of entries) {
    const absolutePath = path.join(dir, entry.name);
    const relativePath = prefix ? `${prefix}/${entry.name}` : entry.name;

    if (entry.isDirectory()) {
      files.push(...(await gatherFiles(absolutePath, relativePath)));
      continue;
    }

    files.push(relativePath.replace(/\\/g, '/'));
  }

  return files.sort();
}

function shouldRemoveExecutableArtifactFile(relativePath: string): boolean {
  const normalized = relativePath.replace(/\\/g, '/').toLowerCase();
  if (normalized.endsWith('.map')) {
    return true;
  }

  if (
    normalized.endsWith('.sh') ||
    normalized.endsWith('.bat') ||
    normalized.endsWith('.cmd') ||
    normalized.endsWith('.ps1') ||
    normalized.endsWith('.exe') ||
    normalized.endsWith('.dll') ||
    normalized.endsWith('.so') ||
    normalized.endsWith('.dylib')
  ) {
    return true;
  }

  if (normalized.endsWith('/xdg-open') || normalized.includes('/schema-engine-')) {
    return true;
  }

  if (
    normalized.endsWith('.ts') ||
    normalized.endsWith('.tsx') ||
    normalized.endsWith('.jsx') ||
    normalized.endsWith('.mts') ||
    normalized.endsWith('.cts')
  ) {
    return !(
      normalized.endsWith('.d.ts') ||
      normalized.endsWith('.d.mts') ||
      normalized.endsWith('.d.cts')
    );
  }

  return false;
}

function isAllowedBundledPluginRuntimeBinary(relativePath: string): boolean {
  const normalized = relativePath.replace(/\\/g, '/').toLowerCase();
  if (!normalized.endsWith('.node')) {
    return false;
  }

  return (
    normalized.includes('node_modules/.prisma/client/') ||
    normalized.includes('node_modules/@prisma/engines/') ||
    normalized.includes('node_modules/prisma/')
  );
}

function shouldRemoveBundledPluginPath(relativePath: string): boolean {
  const normalized = relativePath.replace(/\\/g, '/').toLowerCase();

  if (normalized === 'node_modules/.bin' || normalized.startsWith('node_modules/.bin/')) {
    return true;
  }

  if (normalized === 'node_modules/@rollup' || normalized.startsWith('node_modules/@rollup/')) {
    return true;
  }

  if (normalized === 'node_modules/fsevents' || normalized.startsWith('node_modules/fsevents/')) {
    return true;
  }

  if (normalized.includes('/test/') || normalized.includes('/tests/') || normalized.includes('/integration/')) {
    return true;
  }

  if (normalized.endsWith('.node') && !isAllowedBundledPluginRuntimeBinary(normalized)) {
    return true;
  }

  return false;
}

async function pruneExecutablePackageArtifacts(stagingDir: string): Promise<void> {
  const files = await gatherFiles(stagingDir);
  const pluginPathsToRemove = Array.from(
    new Set(
      files
        .filter((relativePath) => shouldRemoveBundledPluginPath(relativePath))
        .map((relativePath) => {
          const normalized = relativePath.replace(/\\/g, '/');
          if (normalized.startsWith('node_modules/@rollup/')) {
            return 'node_modules/@rollup';
          }
          if (normalized.startsWith('node_modules/fsevents/')) {
            return 'node_modules/fsevents';
          }
          if (normalized.startsWith('node_modules/.bin/')) {
            return 'node_modules/.bin';
          }
          return normalized;
        }),
    ),
  ).sort((left, right) => right.length - left.length);

  await Promise.all(
    pluginPathsToRemove.map((relativePath) =>
      fs.rm(path.join(stagingDir, relativePath), { recursive: true, force: true }),
    ),
  );

  await Promise.all(
    files
      .filter((relativePath) => shouldRemoveExecutableArtifactFile(relativePath))
      .map((relativePath) => fs.rm(path.join(stagingDir, relativePath), { force: true })),
  );
}

async function calculateFileSha256(filePath: string): Promise<string> {
  const buffer = await fs.readFile(filePath);
  return createHash('sha256').update(buffer).digest('hex');
}

async function writeChecksumsJson(stagingDir: string): Promise<Record<string, string>> {
  const files = await gatherFiles(stagingDir);
  const checksums: Record<string, string> = {};

  for (const relativePath of files) {
    if (relativePath === 'checksums.json') {
      continue;
    }
    checksums[relativePath] = await calculateFileSha256(path.join(stagingDir, relativePath));
  }

  await fs.writeFile(
    path.join(stagingDir, 'checksums.json'),
    JSON.stringify(checksums, null, 2),
    'utf-8',
  );

  return checksums;
}

async function ensurePluginSourcePrepared(
  sourceDir: string,
  manifest: { entryModule?: string },
  config: PluginSourceConfig,
): Promise<PreparedPluginSource> {
  const entryRoot = sanitizeManifestEntryRoot(manifest.entryModule);
  const entryRootPath = entryRoot ? path.join(sourceDir, entryRoot) : null;
  const nodeModulesPath = path.join(sourceDir, 'node_modules');
  const needsEntryRoot = entryRootPath ? !(await pathExists(entryRootPath)) : false;
  const needsNodeModules = Boolean(config.includeNodeModules) && !(await pathExists(nodeModulesPath));

  if (!needsEntryRoot && !needsNodeModules) {
    return {
      async cleanup() {},
    };
  }

  const createdPaths: string[] = [];

  if (!config.prepareCommands?.length) {
    const missingTargets = [
      ...(needsEntryRoot && entryRoot ? [`entry root "${entryRoot}"`] : []),
      ...(needsNodeModules ? ['node_modules'] : []),
    ].join(', ');
    throw new Error(`Plugin source for ${sourceDir} is missing ${missingTargets} and no prepareCommands are configured`);
  }

  for (const command of config.prepareCommands) {
    await runShellCommand(command, sourceDir);
  }

  if (needsEntryRoot && entryRootPath && (await pathExists(entryRootPath))) {
    createdPaths.push(entryRootPath);
  }

  if (needsNodeModules && (await pathExists(nodeModulesPath))) {
    createdPaths.push(nodeModulesPath);
  }

  return {
    async cleanup() {
      for (const targetPath of createdPaths.sort((left, right) => right.length - left.length)) {
        await fs.rm(targetPath, { recursive: true, force: true });
      }
    },
  };
}

async function createZipArchive(sourceDir: string, outputFilePath: string): Promise<void> {
  await ensureDir(path.dirname(outputFilePath));

  await new Promise<void>((resolve, reject) => {
    const output = createWriteStream(outputFilePath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => resolve());
    output.on('error', reject);
    archive.on('error', reject);

    archive.pipe(output);
    archive.directory(sourceDir, false);
    archive.finalize().catch(reject);
  });
}

async function maybeWriteDetachedSignature(outputFilePath: string): Promise<string | undefined> {
  const privateKeyPath = process.env.OFFICIAL_EXTENSION_SIGNING_KEY_PATH;
  const privateKeyPem = process.env.OFFICIAL_EXTENSION_SIGNING_KEY;
  const keyMaterial = privateKeyPem || (privateKeyPath ? await fs.readFile(privateKeyPath, 'utf-8') : null);

  if (!keyMaterial) {
    return undefined;
  }

  const artifactBuffer = await fs.readFile(outputFilePath);
  const artifactHash = createHash('sha256').update(artifactBuffer).digest();
  const signatureBase64 = sign(null, artifactHash, keyMaterial).toString('base64');
  const signaturePath = `${outputFilePath}.sig`;
  await fs.writeFile(signaturePath, signatureBase64, 'utf-8');
  return signaturePath;
}

async function writeArtifactSidecars(outputFilePath: string): Promise<{
  sha256: string;
  sizeBytes: number;
  signaturePath?: string;
}> {
  const stat = await fs.stat(outputFilePath);
  const sha256 = await calculateFileSha256(outputFilePath);
  await fs.writeFile(`${outputFilePath}.sha256`, `${sha256}  ${path.basename(outputFilePath)}\n`, 'utf-8');
  const signaturePath = await maybeWriteDetachedSignature(outputFilePath);
  return {
    sha256,
    sizeBytes: stat.size,
    signaturePath,
  };
}

async function stagePluginArtifact(entry: OfficialCatalogEntry, stagingDir: string): Promise<string[]> {
  const sourceDir = path.join(REPO_ROOT, 'extensions', 'plugins', entry.slug);
  const manifestPath = path.join(sourceDir, 'manifest.json');
  const packageJsonPath = path.join(sourceDir, 'package.json');
  const readmePath = path.join(sourceDir, 'README.md');
  const localLicensePath = path.join(sourceDir, 'LICENSE');
  const config = OFFICIAL_PLUGIN_SOURCE_CONFIG[entry.slug] || {};

  if (!(await pathExists(manifestPath))) {
    throw new Error(`Plugin manifest not found for ${entry.slug}: ${manifestPath}`);
  }

  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf-8')) as {
    version?: string;
    entryModule?: string;
  };
  const packageJson = (await pathExists(packageJsonPath))
    ? (JSON.parse(await fs.readFile(packageJsonPath, 'utf-8')) as { version?: string })
    : null;

  if (manifest.version && manifest.version !== entry.version) {
    throw new Error(
      `Plugin ${entry.slug} manifest version ${manifest.version} does not match official catalog version ${entry.version}`,
    );
  }

  if (packageJson?.version && packageJson.version !== entry.version) {
    throw new Error(
      `Plugin ${entry.slug} package.json version ${packageJson.version} does not match official catalog version ${entry.version}`,
    );
  }

  const preparedSource = await ensurePluginSourcePrepared(sourceDir, manifest, config);

  try {
    await copyIfExists(manifestPath, path.join(stagingDir, 'manifest.json'));
    await copyIfExists(packageJsonPath, path.join(stagingDir, 'package.json'));
    await copyIfExists(readmePath, path.join(stagingDir, 'README.md'));
    await copyIfExists(localLicensePath, path.join(stagingDir, 'LICENSE'));

    if (!(await pathExists(path.join(stagingDir, 'LICENSE')))) {
      await copyIfExists(ROOT_LICENSE_PATH, path.join(stagingDir, 'LICENSE'));
    }

    const entryRoot = sanitizeManifestEntryRoot(manifest.entryModule);
    if (entryRoot) {
      const sourceEntryRoot = path.join(sourceDir, entryRoot);
      if (!(await pathExists(sourceEntryRoot))) {
        throw new Error(`Plugin entry root "${entryRoot}" not found for ${entry.slug}`);
      }
      await fs.cp(sourceEntryRoot, path.join(stagingDir, entryRoot), {
        recursive: true,
        force: true,
      });
    }

    if (config.includeNodeModules) {
      const nodeModulesPath = path.join(sourceDir, 'node_modules');
      if (!(await pathExists(nodeModulesPath))) {
        throw new Error(
          `Plugin ${entry.slug} is configured to vendor node_modules, but ${nodeModulesPath} is missing`,
        );
      }
      await fs.cp(nodeModulesPath, path.join(stagingDir, 'node_modules'), {
        recursive: true,
        force: true,
      });
    }

    await pruneExecutablePackageArtifacts(stagingDir);
    await writeChecksumsJson(stagingDir);
    return gatherFiles(stagingDir);
  } finally {
    await preparedSource.cleanup();
  }
}

async function ensureThemePackPath(sourceDir: string, relativePath?: string): Promise<void> {
  if (!relativePath) {
    return;
  }

  const absolutePath = path.join(sourceDir, relativePath);
  if (!(await pathExists(absolutePath))) {
    throw new Error(`Theme Pack source is missing required path: ${relativePath}`);
  }
}

async function stageThemeArtifact(entry: OfficialCatalogEntry, stagingDir: string): Promise<string[]> {
  const packageDir = path.join(REPO_ROOT, 'packages', 'shop-themes', entry.slug);
  const sourceDir = path.join(packageDir, 'theme-pack');
  const themeManifestPath = path.join(sourceDir, 'theme.json');
  const packageRootJsonPath = path.join(packageDir, 'package.json');
  const packageRootReadmePath = path.join(packageDir, 'README.md');

  if (!(await pathExists(sourceDir))) {
    throw new Error(`Theme Pack source directory not found for ${entry.slug}: ${sourceDir}`);
  }

  if (!(await pathExists(themeManifestPath))) {
    throw new Error(`Theme Pack manifest not found for ${entry.slug}: ${themeManifestPath}`);
  }

  const packageJson = JSON.parse(await fs.readFile(packageRootJsonPath, 'utf-8')) as {
    version?: string;
  };
  const manifest = JSON.parse(await fs.readFile(themeManifestPath, 'utf-8')) as ThemePackSourceManifest;

  if (packageJson.version && packageJson.version !== entry.version) {
    throw new Error(
      `Theme ${entry.slug} package.json version ${packageJson.version} does not match official catalog version ${entry.version}`,
    );
  }

  if (manifest.slug !== entry.slug) {
    throw new Error(`Theme Pack manifest slug ${manifest.slug} does not match official catalog slug ${entry.slug}`);
  }

  if (manifest.schemaVersion !== 1) {
    throw new Error(`Theme Pack manifest schemaVersion ${manifest.schemaVersion} is not supported for ${entry.slug}`);
  }

  if (manifest.name !== entry.name) {
    throw new Error(`Theme Pack manifest name ${manifest.name} does not match official catalog name ${entry.name}`);
  }

  if (manifest.version !== entry.version) {
    throw new Error(
      `Theme Pack manifest version ${manifest.version} does not match official catalog version ${entry.version}`,
    );
  }

  if (manifest.target !== 'shop') {
    throw new Error(`Theme Pack manifest target ${manifest.target} is not supported for official shop theme ${entry.slug}`);
  }

  if (manifest.compatibility?.minCoreVersion && manifest.compatibility.minCoreVersion !== entry.minCoreVersion) {
    throw new Error(
      `Theme Pack manifest minCoreVersion ${manifest.compatibility.minCoreVersion} does not match official catalog version ${entry.minCoreVersion}`,
    );
  }

  if (manifest['x-jiffoo-renderer-mode'] !== 'embedded') {
    throw new Error(`Theme Pack manifest for ${entry.slug} must declare x-jiffoo-renderer-mode=embedded`);
  }

  if (manifest['x-jiffoo-renderer-slug'] !== entry.slug) {
    throw new Error(
      `Theme Pack manifest renderer slug ${manifest['x-jiffoo-renderer-slug']} does not match official theme slug ${entry.slug}`,
    );
  }

  await ensureThemePackPath(sourceDir, manifest.entry?.tokensCSS || 'tokens.css');
  await ensureThemePackPath(sourceDir, manifest.entry?.templatesDir || 'templates');
  await ensureThemePackPath(sourceDir, manifest.entry?.assetsDir);
  await ensureThemePackPath(sourceDir, manifest.entry?.settingsSchema);
  await ensureThemePackPath(sourceDir, manifest.entry?.presetsDir);

  await fs.cp(sourceDir, stagingDir, { recursive: true, force: true });
  await copyIfExists(packageRootReadmePath, path.join(stagingDir, 'README.md'));
  await copyIfExists(ROOT_LICENSE_PATH, path.join(stagingDir, 'LICENSE'));

  await writeChecksumsJson(stagingDir);
  return gatherFiles(stagingDir);
}

async function resolveThemeAppPackagePath(entry: OfficialCatalogEntry): Promise<string> {
  const packageDir = path.join(REPO_ROOT, 'packages', 'shop-themes', entry.slug);
  const manifestPath = path.join(packageDir, 'theme-app.json');
  const packageJsonPath = path.join(packageDir, 'package.json');
  const packageZipPath = path.join(packageDir, 'dist', `${entry.slug}-${entry.version}.theme-app.zip`);

  if (!(await pathExists(manifestPath))) {
    throw new Error(`Theme App manifest not found for ${entry.slug}: ${manifestPath}`);
  }
  if (!(await pathExists(packageZipPath))) {
    throw new Error(`Theme App package not found for ${entry.slug}: ${packageZipPath}`);
  }

  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf-8')) as ThemeAppSourceManifest;
  const packageJson = JSON.parse(await fs.readFile(packageJsonPath, 'utf-8')) as { version?: string };
  if (manifest.schemaVersion !== 1 || manifest.type !== 'theme-app') {
    throw new Error(`Theme App manifest is invalid for ${entry.slug}`);
  }
  if (manifest.slug !== entry.slug || manifest.name !== entry.name || manifest.version !== entry.version) {
    throw new Error(`Theme App manifest identity does not match official catalog for ${entry.slug}`);
  }
  if (packageJson.version && packageJson.version !== entry.version) {
    throw new Error(`Theme App package.json version ${packageJson.version} does not match ${entry.version}`);
  }
  if (manifest.target !== 'shop') {
    throw new Error(`Theme App target ${manifest.target} is not supported for ${entry.slug}`);
  }
  if (manifest.compatibility?.minCoreVersion && manifest.compatibility.minCoreVersion !== entry.minCoreVersion) {
    throw new Error(`Theme App minCoreVersion does not match official catalog for ${entry.slug}`);
  }
  return packageZipPath;
}

async function buildSingleArtifact(
  entry: OfficialCatalogEntry,
  outputDir: string,
  artifactBaseUrl?: string,
): Promise<BuiltArtifactSummary> {
  const kind = toOfficialArtifactKind(entry);
  const version = entry.version;
  const extension = kind === 'theme-app' ? 'theme-app.zip' : kind === 'theme' ? 'jtheme' : 'jplugin';
  const kindDir = kind === 'theme-app' ? 'theme-apps' : kind === 'theme' ? 'themes' : 'plugins';
  const relativePath = `${kindDir}/${entry.slug}/${version}.${extension}`;
  const outputFilePath = path.join(outputDir, relativePath);
  const sourceDir = path.join(
    REPO_ROOT,
    kind === 'theme-app' || kind === 'theme'
      ? path.join('packages', 'shop-themes', entry.slug, 'theme-pack')
      : path.join('extensions', 'plugins', entry.slug),
  );

  if (kind === 'theme-app') {
    const sourcePackagePath = await resolveThemeAppPackagePath(entry);
    await fs.mkdir(path.dirname(outputFilePath), { recursive: true });
    await fs.copyFile(sourcePackagePath, outputFilePath);
    const sidecars = await writeArtifactSidecars(outputFilePath);
    return {
      slug: entry.slug,
      kind: 'theme',
      artifactKind: entry.artifactKind,
      version,
      packageUrl: getDefaultPackageUrl(entry, artifactBaseUrl),
      filePath: outputFilePath,
      relativePath,
      sha256: sidecars.sha256,
      sizeBytes: sidecars.sizeBytes,
      sourceDir: path.dirname(sourcePackagePath),
      includedFiles: [path.relative(path.dirname(sourcePackagePath), sourcePackagePath)],
      ...(sidecars.signaturePath ? { signaturePath: sidecars.signaturePath } : {}),
    };
  }

  const stagingDir = await fs.mkdtemp(path.join(os.tmpdir(), `official-artifact-${entry.slug}-`));

  try {
    const includedFiles =
      kind === 'theme'
        ? await stageThemeArtifact(entry, stagingDir)
        : await stagePluginArtifact(entry, stagingDir);

    await createZipArchive(stagingDir, outputFilePath);
    const sidecars = await writeArtifactSidecars(outputFilePath);

    return {
      slug: entry.slug,
      kind: kind === 'plugin' ? 'plugin' : 'theme',
      artifactKind: entry.artifactKind,
      version,
      packageUrl: getDefaultPackageUrl(entry, artifactBaseUrl),
      filePath: outputFilePath,
      relativePath,
      sha256: sidecars.sha256,
      sizeBytes: sidecars.sizeBytes,
      sourceDir,
      includedFiles,
      ...(sidecars.signaturePath ? { signaturePath: sidecars.signaturePath } : {}),
    };
  } finally {
    await fs.rm(stagingDir, { recursive: true, force: true });
  }
}

export async function buildOfficialArtifacts(
  options: BuildOfficialArtifactsOptions = {},
): Promise<BuildOfficialArtifactsResult> {
  const outputDir = path.resolve(options.outputDir || DEFAULT_OUTPUT_DIR);
  const slugSet = new Set(options.slugs || []);
  const kindSet = new Set(options.kinds || []);

  const selectedEntries = OFFICIAL_LAUNCH_EXTENSIONS.filter((entry) => {
    if (entry.deliveryMode !== 'package-managed') {
      return false;
    }

    if (slugSet.size > 0 && !slugSet.has(entry.slug)) {
      return false;
    }

    if (kindSet.size > 0 && !kindSet.has(toOfficialArtifactKind(entry))) {
      return false;
    }

    return true;
  });

  if (selectedEntries.length === 0) {
    throw new Error('No official extensions matched the requested build filters');
  }

  await fs.rm(outputDir, { recursive: true, force: true });
  await ensureDir(outputDir);

  const items: BuiltArtifactSummary[] = [];
  for (const entry of selectedEntries) {
    items.push(await buildSingleArtifact(entry, outputDir, options.artifactBaseUrl));
  }

  const result: BuildOfficialArtifactsResult = {
    generatedAt: new Date().toISOString(),
    outputDir,
    items,
  };

  await fs.writeFile(
    path.join(outputDir, 'index.json'),
    JSON.stringify(result, null, 2),
    'utf-8',
  );

  return result;
}

async function main() {
  // --- Deprecation notice (R1.6) ---
  // The javascript-obfuscator-based artifact protection is deprecated.
  // Commercial capability protection is migrating to server-side Entitlement
  // Service validation. See ADR: 2026-07-commercial-protection-server-side.md
  console.warn(
    '[DEPRECATION] build:official-artifacts: Code obfuscation as a commercial ' +
      'protection mechanism is deprecated as of Jiffoo v1.1.x. ' +
      'Commercial capability protection is migrating to server-side Entitlement ' +
      'Service validation (closed-source Platform API). ' +
      'See .kiro/specs/architecture-decisions/2026-07-commercial-protection-server-side.md ' +
      'for the full decision record and migration guidance.'
  );

  const options = parseArgs(process.argv.slice(2));
  const result = await buildOfficialArtifacts(options);

  console.log(`Built ${result.items.length} official artifacts into ${result.outputDir}`);
  for (const item of result.items) {
    console.log(
      `- ${item.kind} ${item.slug}@${item.version} -> ${item.relativePath} (${item.sizeBytes} bytes, sha256=${item.sha256})`,
    );
  }
}

// Use pathToFileURL for Windows-compatible comparison (handles spaces in paths)
import { pathToFileURL } from 'url';
const _currentUrl = import.meta.url;
const _argvUrl = process.argv[1] ? pathToFileURL(process.argv[1]).href : '';
if (_currentUrl === _argvUrl) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.message : error);
    process.exit(1);
  });
}
