/**
 * Auth Service
 *
 * Handles user authentication, registration, and token management.
 * Supports OAuth2-compliant token responses with JWT-based authentication.
 */

import { prisma } from '@/config/database';
import { PasswordUtils } from '@/utils/password';
import { JwtUtils } from '@/utils/jwt';
import { LoginRequest, RegisterRequest } from './types';
import { EmailVerificationService } from '@/services/email-verification.service';
import { shouldRequirePasswordRotation } from './bootstrap';
import { createAuthUser, findAuthUserByEmail, findAuthUserById, findAuthUserByIdentifier } from './user-compat';
import crypto from 'node:crypto';

const DEFAULT_DEMO_ADMIN_EMAIL = 'admin@jiffoo.com';
const DEFAULT_DEMO_ADMIN_PASSWORD = 'admin123';

export interface AuthResponse {
  user: {
    id: string;
    email: string;
    username: string;
    role: string;
    emailVerified?: boolean;
    avatar?: string | null;
    requiresPasswordRotation?: boolean;
  };
  // OAuth2 standard fields
  access_token: string;
  token_type: string;
  expires_in: number;
  refresh_token?: string;
  // Compatible with old fields
  token: string;
}

export interface LoginConfigResponse {
  demoModeEnabled: boolean;
  demoCredentials: {
    email: string;
    password: string;
  } | null;
}

const authUserSelect = {
  id: true,
  email: true,
  username: true,
  password: true,
  role: true,
  isActive: true,
  emailVerified: true,
  avatar: true,
} as const;

export class AuthService {
  static async guest(input: { guestId?: string; installId?: string; deviceId?: string }): Promise<AuthResponse & { accountType: 'guest'; guestId: string }> {
    const suppliedGuestDigest = input.guestId?.trim().match(/^guest_([a-f0-9]{32})$/i)?.[1];
    const hint = input.installId || input.deviceId || input.guestId || crypto.randomUUID();
    const digest = suppliedGuestDigest || crypto.createHash('sha256').update(hint).digest('hex').slice(0, 32);
    const guestId = input.guestId?.trim() || `guest_${digest}`;
    const email = `${digest}@guest.bokmoo.invalid`;

    let user = await findAuthUserByEmail(email);
    if (!user) {
      user = await createAuthUser({
        email,
        username: guestId.slice(0, 50),
        password: await PasswordUtils.hash(crypto.randomUUID()),
        role: 'GUEST',
        emailVerified: true,
      });
    }

    if (!user.isActive) throw new Error('Account is inactive');
    const accessToken = JwtUtils.sign({ userId: user.id, email: user.email, role: user.role });
    const refreshToken = JwtUtils.signRefresh({ userId: user.id });
    return {
      user: {
        id: user.id,
        email: '',
        username: user.username,
        role: user.role,
        emailVerified: true,
        avatar: user.avatar,
      },
      accountType: 'guest',
      guestId,
      access_token: accessToken,
      token_type: 'Bearer',
      expires_in: 604800,
      refresh_token: refreshToken,
      token: accessToken,
    };
  }
  private static isDemoModeEnabled(): boolean {
    return process.env.JIFFOO_DEMO_MODE === 'true';
  }

  private static shouldRequireEmailVerification(): boolean {
    return process.env.AUTH_REQUIRE_EMAIL_VERIFICATION?.trim().toLowerCase() !== 'false';
  }

  private static resolveDemoCredentials() {
    return {
      email: process.env.JIFFOO_DEMO_ADMIN_EMAIL?.trim() || DEFAULT_DEMO_ADMIN_EMAIL,
      password: process.env.JIFFOO_DEMO_ADMIN_PASSWORD || DEFAULT_DEMO_ADMIN_PASSWORD,
    };
  }

  private static async ensureDemoModeAdminCredentials(credentials: { email: string; password: string }): Promise<void> {
    const existingUser = await prisma.user.findUnique({
      where: { email: credentials.email },
      select: {
        id: true,
        password: true,
        role: true,
        isActive: true,
        emailVerified: true,
      },
    });

    const hashedPassword = await PasswordUtils.hash(credentials.password);

    if (!existingUser) {
      await prisma.user.create({
        data: {
          email: credentials.email,
          username: credentials.email.split('@')[0] || 'admin',
          password: hashedPassword,
          role: 'ADMIN',
          isActive: true,
          emailVerified: true,
        },
      });
      return;
    }

    const passwordMatches = await PasswordUtils.verify(credentials.password, existingUser.password);
    if (
      passwordMatches &&
      existingUser.role === 'ADMIN' &&
      existingUser.isActive &&
      existingUser.emailVerified
    ) {
      return;
    }

    await prisma.user.update({
      where: { id: existingUser.id },
      data: {
        password: hashedPassword,
        role: 'ADMIN',
        isActive: true,
        emailVerified: true,
      },
    });
  }

  static async getLoginConfig(): Promise<LoginConfigResponse> {
    if (!this.isDemoModeEnabled()) {
      return {
        demoModeEnabled: false,
        demoCredentials: null,
      };
    }

    const credentials = this.resolveDemoCredentials();
    await this.ensureDemoModeAdminCredentials(credentials);

    return {
      demoModeEnabled: true,
      demoCredentials: credentials,
    };
  }

  /**
   * Register a new user account
   *
   * Creates a new user with hashed password and generates access and refresh tokens.
   * Validates that email and username are unique before creating the account.
   *
   * @param data User registration data containing email, username, and password
   * @returns Authentication response with user details and OAuth2-compliant tokens
   * @throws Error if a user with the same email or username already exists
   */
  static async register(data: RegisterRequest): Promise<AuthResponse> {
    const existingEmailUser = await findAuthUserByEmail(data.email);
    if (existingEmailUser) {
      if (!existingEmailUser.emailVerified) {
        const error = new Error('This email is already registered but has not been verified yet. Enter the verification code we sent, or request a new one.');
        Object.assign(error, { code: 'EMAIL_NOT_VERIFIED' });
        throw error;
      }
      throw new Error('User with this email or username already exists');
    }

    const existingUsername = await prisma.user.findFirst({
      where: { username: data.username },
      select: { id: true },
    });
    if (existingUsername) throw new Error('User with this email or username already exists');

    const hashedPassword = await PasswordUtils.hash(data.password);
    const requireEmailVerification = this.shouldRequireEmailVerification();
    // createAuthUser tolerates legacy databases without the emailVerified column
    const user = await createAuthUser({
      email: data.email,
      username: data.username,
      password: hashedPassword,
      role: 'USER',
      emailVerified: !requireEmailVerification,
    });

    if (requireEmailVerification) {
      // Send verification email
      const verificationDelivery = await EmailVerificationService.sendVerificationEmail(
        user.id,
        user.email,
        user.username
      );
      if (!verificationDelivery.success) {
        throw new Error(verificationDelivery.error || 'Verification email could not be sent');
      }
    }

    const token = JwtUtils.sign({
      userId: user.id,
      email: user.email,
      role: user.role
    });

    const refreshToken = JwtUtils.signRefresh({
      userId: user.id
    });

    return {
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        role: user.role,
        emailVerified: user.emailVerified,
        avatar: user.avatar,
        requiresPasswordRotation: false,
      },
      // OAuth2 standard fields
      access_token: token,
      token_type: 'Bearer',
      expires_in: 604800, // 7 days
      refresh_token: refreshToken,
      // Compatible with old fields
      token
    };
  }

  static async convertGuest(userId: string, data: RegisterRequest): Promise<AuthResponse> {
    const guest = await findAuthUserById(userId);
    if (!guest || guest.role !== 'GUEST' || !guest.email.endsWith('@guest.bokmoo.invalid')) {
      throw new Error('Guest session is invalid');
    }
    const duplicate = await prisma.user.findFirst({
      where: { OR: [{ email: data.email }, { username: data.username }], NOT: { id: userId } },
      select: { id: true },
    });
    if (duplicate) throw new Error('User with this email or username already exists');

    const user = await prisma.user.update({
      where: { id: userId },
      data: {
        email: data.email,
        username: data.username,
        password: await PasswordUtils.hash(data.password),
        role: 'USER',
        emailVerified: !this.shouldRequireEmailVerification(),
      },
      select: authUserSelect,
    });
    if (!user.emailVerified) {
      const verificationDelivery = await EmailVerificationService.sendVerificationEmail(
        user.id,
        user.email,
        user.username
      );
      if (!verificationDelivery.success) {
        throw new Error(verificationDelivery.error || 'Verification email could not be sent');
      }
    }
    const token = JwtUtils.sign({ userId: user.id, email: user.email, role: user.role });
    const refreshToken = JwtUtils.signRefresh({ userId: user.id });
    return {
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        role: user.role,
        emailVerified: user.emailVerified,
        avatar: user.avatar,
        requiresPasswordRotation: false,
      },
      access_token: token,
      token_type: 'Bearer',
      expires_in: 604800,
      refresh_token: refreshToken,
      token,
    };
  }

  /**
   * Authenticate a user and generate session tokens
   *
   * Validates user credentials and generates new access and refresh tokens upon successful authentication.
   *
   * @param data Login credentials containing an email or username and password
   * @returns Authentication response with user details and OAuth2-compliant tokens
   * @throws Error if the identifier does not exist, is ambiguous, or the password is incorrect
   */
  static async login(data: LoginRequest): Promise<AuthResponse> {
    const identifier = data.identifier ?? data.email;
    const user = await findAuthUserByIdentifier(identifier);

    if (!user) {
      throw new Error('Invalid email or password');
    }

    const isValid = await PasswordUtils.verify(data.password, user.password);
    if (!isValid) {
      throw new Error('Invalid email or password');
    }
    if (!user.isActive) {
      throw new Error('Account is inactive');
    }

    // Check if email is verified
    if (!user.emailVerified) {
      throw new Error('Email not verified. Please check your email for verification link.');
    }

    const requiresPasswordRotation = await shouldRequirePasswordRotation(user.email);

    const token = JwtUtils.sign({
      userId: user.id,
      email: user.email,
      role: user.role
    });

    const refreshToken = JwtUtils.signRefresh({
      userId: user.id
    });

    return {
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        role: user.role,
        emailVerified: user.emailVerified,
        avatar: user.avatar,
        requiresPasswordRotation,
      },
      // OAuth2 standard fields
      access_token: token,
      token_type: 'Bearer',
      expires_in: 604800, // 7 days
      refresh_token: refreshToken,
      // Compatible with old fields
      token
    };
  }

  /**
   * Get current user details by user ID
   *
   * Retrieves the authenticated user's profile information including id, email,
   * username, role, avatar, and account creation date.
   *
   * @param userId The unique identifier of the user
   * @returns User profile object with selected fields
   * @throws Error if the user is not found
   */
  static async getCurrentUser(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        username: true,
        role: true,
        isActive: true,
        avatar: true,
        createdAt: true
      }
    });

    if (!user) {
      throw new Error('User not found');
    }
    if (!user.isActive) {
      throw new Error('Account is inactive');
    }

    return {
      ...user,
      requiresPasswordRotation: await shouldRequirePasswordRotation(user.email),
    };
  }

  /**
   * Generate a new access token for an authenticated user
   *
   * Creates a new JWT access token for the user based on their current profile.
   * This method is used when a valid refresh token provides the userId.
   *
   * @param userId The unique identifier of the user
   * @returns Object containing the new access token
   * @throws Error if the user is not found
   */
  static async refreshToken(userId: string): Promise<{ token: string }> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: authUserSelect,
    });

    if (!user) {
      throw new Error('User not found');
    }
    if (!user.isActive) {
      throw new Error('Account is inactive');
    }

    const token = JwtUtils.sign({
      userId: user.id,
      email: user.email,
      role: user.role
    });

    return { token };
  }

  /**
   * Refresh an authenticated session using a refresh token
   *
   * Validates the refresh token and generates new access and refresh tokens.
   * Implements token rotation by issuing a new refresh token with each refresh.
   *
   * @param refreshToken The JWT refresh token to validate and exchange
   * @returns Authentication response with user details and new OAuth2-compliant tokens
   * @throws Error if the refresh token is invalid, expired, or the user is not found
   */
  static async refreshSession(refreshToken: string): Promise<AuthResponse> {
    try {
      const payload = JwtUtils.verify(refreshToken);
      if (!payload || !payload.userId || payload.type !== 'refresh') {
        throw new Error('Invalid refresh token');
      }

      const user = await findAuthUserById(payload.userId);

      if (!user) {
        throw new Error('User not found');
      }
      if (!user.isActive) {
        throw new Error('Account is inactive');
      }

      // Generate new tokens
      const accessToken = JwtUtils.sign({
        userId: user.id,
        email: user.email,
        role: user.role
      });

      // Optional: Rotate refresh token? (Return new one, same expiry or extended)
      // For now, let's keep the same or issue a new one. OAuth2 usually issues a new one.
      const newRefreshToken = JwtUtils.signRefresh({ userId: user.id });

      return {
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          role: user.role,
          emailVerified: user.emailVerified,
          avatar: user.avatar
        },
        access_token: accessToken,
        token_type: 'Bearer',
        expires_in: 604800,
        refresh_token: newRefreshToken,
        token: accessToken
      };
    } catch (error) {
      throw new Error('Invalid refresh token');
    }
  }

  /**
   * Verify and decode a JWT token
   *
   * Validates the token signature and expiration, then returns the decoded payload.
   *
   * @param token The JWT token to verify
   * @returns Decoded token payload containing user information
   */
  static verifyToken(token: string) {
    return JwtUtils.verify(token);
  }
}
